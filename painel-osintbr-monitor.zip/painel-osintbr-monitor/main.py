#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Painel OSINTBR Monitor — CLI Termux/Kali
Coleta GitHub (estável) + páginas públicas + checagem de username.
"""
from __future__ import annotations
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from core import ui
from core import store
from modules import github, webpage, compare, username


def show_snapshot(snap: dict):
    ui.ok(f"Fonte: {snap.get('source') or snap.get('platform')}")
    for label, key in [
        ("Nome", "name"),
        ("Bio", "bio"),
        ("Login", "login"),
        ("Seguidores", "followers"),
        ("Seguindo", "following"),
        ("Posts/Repos", "posts"),
        ("Repos públicos", "public_repos"),
        ("Empresa", "company"),
        ("Local", "location"),
        ("Blog", "blog"),
        ("Twitter", "twitter"),
        ("E-mail", "email"),
        ("Atualizado", "updated_at"),
        ("URL", "url"),
        ("HTTP", "http"),
    ]:
        v = snap.get(key)
        if v is not None and v != "":
            print(f"  {ui.Y}{label}:{ui.Z} {v}")
    if snap.get("repos_recent"):
        ui.info("Repos recentes:")
        for r in snap["repos_recent"]:
            print(f"    · {r}")
    if snap.get("emails"):
        ui.info("E-mails: " + ", ".join(snap["emails"]))
    if snap.get("warning"):
        ui.warn(snap["warning"])
    if snap.get("blocked"):
        ui.warn("Possível bloqueio/login na página")


def action_github():
    ui.title("Coletar GitHub")
    q = ui.ask("@usuario ou URL GitHub")
    if not q:
        return
    ui.progress(["verificando usuário…", "consultando API pública…", "montando perfil…"])
    try:
        snap = github.collect(q)
        show_snapshot(snap)
        if ui.ask("Salvar como alvo monitorado? (s/N)").lower() == "s":
            label = ui.ask("rótulo") or q
            store.add_target(label, q, "github", snap)
            ui.ok("Alvo salvo em data/targets.json")
    except Exception as e:
        ui.err(str(e))


def action_page():
    ui.title("Coletar página / perfil (URL)")
    q = ui.ask("URL completa")
    if not q:
        return
    ui.progress(["conectando…", "baixando HTML…", "extraindo metadados…"])
    try:
        snap = webpage.collect(q)
        show_snapshot(snap)
        if ui.ask("Salvar como alvo? (s/N)").lower() == "s":
            label = ui.ask("rótulo") or q
            store.add_target(label, q, "web", snap)
            ui.ok("Salvo")
    except Exception as e:
        ui.err(str(e))
        ui.warn("Muitas redes (IG/TikTok) bloqueiam. Prefira GitHub ou sites abertos.")


def action_username():
    ui.title("Checar username em sites")
    u = ui.ask("@username")
    if not u:
        return
    ui.progress(["montando lista de sites…", "consultando um a um…"])
    results = username.check(u)
    for r in results:
        st = r.get("status")
        ex = r.get("exists")
        if ex is True:
            mark = f"{ui.G}possível perfil{ui.Z}"
        elif ex is False:
            mark = f"{ui.R}não encontrado{ui.Z}"
        else:
            mark = f"{ui.Y}incerto/bloqueado{ui.Z}"
        print(f"  {r['site']:12} HTTP {st or '—':>4}  {mark}")
        print(f"             {r['url']}")
    ui.warn("HTTP 200 não garante conta ativa (algumas páginas sempre respondem 200).")


def action_list():
    ui.title("Alvos salvos")
    items = store.load_targets()
    if not items:
        ui.warn("Nenhum alvo. Colete e salve antes.")
        return
    for i, t in enumerate(items, 1):
        cur = t.get("current") or {}
        ch = t.get("last_change")
        print(f"{ui.Y}{i}.{ui.Z} [{t['id']}] {t['label']}  ({t.get('kind')})")
        print(f"   {cur.get('name') or '—'} · seguidores {cur.get('followers')} · {t.get('updated_at')}")
        if ch:
            print(f"   {ui.Y}última mudança:{ui.Z} {ch.get('at')} — {'; '.join(ch.get('msgs') or [])}")


def action_recheck():
    ui.title("Rechecagem / comparação")
    items = store.load_targets()
    if not items:
        ui.warn("Sem alvos")
        return
    for i, t in enumerate(items, 1):
        print(f"  {i}. {t['label']} ({t['id']})")
    choice = ui.ask("número do alvo (ou 'todos')")
    if not choice:
        return
    selected = items if choice.lower() == "todos" else []
    if not selected:
        try:
            selected = [items[int(choice) - 1]]
        except Exception:
            ui.err("Opção inválida")
            return
    for t in selected:
        ui.info(f"Checando {t['label']}…")
        try:
            if t.get("kind") == "github":
                snap = github.collect(t["query"])
            else:
                snap = webpage.collect(t["query"])
            msgs = compare.diff(t.get("current"), snap)
            store.update_target(t["id"], snap, msgs if msgs and msgs[0] != "Primeira coleta registrada" else [])
            if msgs and msgs[0] != "Primeira coleta registrada":
                ui.warn("MUDANÇAS:")
                for m in msgs:
                    print(f"   · {m}")
            else:
                ui.ok("Sem alteração relevante")
            show_snapshot(snap)
        except Exception as e:
            ui.err(str(e))


def action_delete():
    items = store.load_targets()
    if not items:
        ui.warn("Vazio")
        return
    for i, t in enumerate(items, 1):
        print(f"  {i}. {t['label']}")
    choice = ui.ask("número para apagar")
    try:
        t = items[int(choice) - 1]
    except Exception:
        ui.err("Inválido")
        return
    if store.remove_target(t["id"]):
        ui.ok("Removido")


def action_about():
    ui.title("Sobre")
    print(
        """
  Painel OSINTBR Monitor — uso em Termux e Kali.
  • GitHub: API oficial (nome, bio, seguidores, repos, edição do perfil)
  • Página: HTML público (título, description, imagem, e-mails, métricas se expostas)
  • Username: checagem HTTP em várias redes (heurística)

  Instagram/TikTok/X costumam bloquear. Isso é limitação da plataforma, não do Termux.
  Dados em: data/targets.json
  Uso apenas em fontes abertas e alvos autorizados.
"""
    )


def main():
    store.ensure_data()
    while True:
        ui.clear()
        ui.banner()
        ui.menu([
            ("1", "Coletar GitHub (recomendado / estável)"),
            ("2", "Coletar página / URL pública"),
            ("3", "Checar username em sites"),
            ("4", "Listar alvos salvos"),
            ("5", "Rechecagem e comparar mudanças"),
            ("6", "Apagar alvo"),
            ("7", "Sobre / limites"),
            ("0", "Sair"),
        ])
        op = ui.ask()
        if op == "0":
            ui.ok("Até logo")
            break
        actions = {
            "1": action_github,
            "2": action_page,
            "3": action_username,
            "4": action_list,
            "5": action_recheck,
            "6": action_delete,
            "7": action_about,
        }
        fn = actions.get(op)
        if not fn:
            ui.err("Opção inválida")
            ui.pause()
            continue
        try:
            fn()
        except KeyboardInterrupt:
            print()
            ui.warn("Cancelado")
        except Exception as e:
            ui.err(str(e))
        ui.pause()


if __name__ == "__main__":
    main()
