# 🔍 Painel OSINTBR Monitor

Ferramenta **CLI** para Termux e Kali: coleta de perfis públicos, comparação de mudanças e checagem de username.

Interface em **verde e amarelo**, fácil de usar, pensada para publicação no GitHub.

---

## O que faz

| Módulo | Função | Confiabilidade |
|--------|--------|----------------|
| **GitHub** | Nome, bio, foto, seguidores, seguindo, repos, empresa, local, blog, twitter, data de atualização do perfil | ⭐⭐⭐⭐⭐ API oficial |
| **Página / URL** | Título, description, imagem, e-mails, métricas se a página expuser | ⭐⭐⭐ sites abertos |
| **Username** | Testa @ em GitHub, GitLab, Reddit, TikTok, IG, X, YouTube, Telegram… | ⭐⭐ heurística HTTP |
| **Monitor** | Salva alvos, recheca e mostra o que mudou | ⭐⭐⭐⭐ |

> Instagram / TikTok / X muitas vezes **bloqueiam** leitura automática. Isso é da plataforma. Para monitoramento estável use **GitHub** ou sites que exponham HTML público.

---

## Instalação — Termux

```bash
pkg update -y
pkg install python git -y
termux-setup-storage

cd ~/storage/downloads
# se baixou o ZIP:
unzip painel-osintbr-monitor.zip -d ~/osintbr-monitor
cd ~/osintbr-monitor/painel-osintbr-monitor

# ou com git:
# git clone https://github.com/SEU_USER/painel-osintbr-monitor.git
# cd painel-osintbr-monitor

pip install -r requirements.txt
python main.py
```

## Instalação — Kali / Debian

```bash
sudo apt update
sudo apt install -y python3 python3-pip python3-venv git
git clone https://github.com/SEU_USER/painel-osintbr-monitor.git
cd painel-osintbr-monitor
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
python main.py
```

---

## Uso rápido

```text
1  →  Coletar GitHub (@torvalds)
2  →  Coletar URL pública
3  →  Checar username em várias redes
5  →  Rechecagem (compara com a versão salva)
```

Dados ficam em `data/targets.json`.

---

## Aviso legal

Use apenas em **fontes abertas** e alvos com **autorização**. Não contorna login, CAPTCHA nem contas privadas.

---

## Estrutura

```text
painel-osintbr-monitor/
├── main.py
├── requirements.txt
├── README.md
├── core/          # UI + armazenamento
├── modules/       # github, webpage, username, compare
└── data/          # targets.json (criado na 1ª execução)
```
