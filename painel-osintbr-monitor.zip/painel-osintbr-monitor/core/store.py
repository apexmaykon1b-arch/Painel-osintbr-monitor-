# -*- coding: utf-8 -*-
"""Persistência local de alvos e versões."""
from __future__ import annotations
import json
import os
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
DATA = ROOT / "data"
TARGETS_FILE = DATA / "targets.json"

def _now() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")

def ensure_data():
    DATA.mkdir(parents=True, exist_ok=True)
    if not TARGETS_FILE.exists():
        TARGETS_FILE.write_text("[]", encoding="utf-8")

def load_targets() -> list:
    ensure_data()
    try:
        return json.loads(TARGETS_FILE.read_text(encoding="utf-8"))
    except Exception:
        return []

def save_targets(items: list):
    ensure_data()
    TARGETS_FILE.write_text(json.dumps(items, ensure_ascii=False, indent=2), encoding="utf-8")

def add_target(label: str, query: str, kind: str, snapshot: dict) -> dict:
    items = load_targets()
    t = {
        "id": f"t_{int(datetime.now().timestamp())}_{len(items)}",
        "label": label or query,
        "query": query,
        "kind": kind,
        "created_at": _now(),
        "updated_at": _now(),
        "current": snapshot,
        "versions": [],
        "last_change": None,
    }
    items.insert(0, t)
    save_targets(items)
    return t

def update_target(tid: str, snapshot: dict, changes: list) -> dict | None:
    items = load_targets()
    for t in items:
        if t["id"] == tid:
            if t.get("current"):
                t.setdefault("versions", [])
                t["versions"].insert(0, t["current"])
                t["versions"] = t["versions"][:20]
            t["current"] = snapshot
            t["updated_at"] = _now()
            if changes:
                t["last_change"] = {"at": _now(), "msgs": changes}
            save_targets(items)
            return t
    return None

def remove_target(tid: str) -> bool:
    items = load_targets()
    n = len(items)
    items = [t for t in items if t["id"] != tid]
    save_targets(items)
    return len(items) < n

def get_target(tid: str) -> dict | None:
    for t in load_targets():
        if t["id"] == tid:
            return t
    return None
