# -*- coding: utf-8 -*-
"""Interface CLI — verde/amarelo estilo bandeira + lupa."""
from __future__ import annotations
import sys
import time

try:
    from colorama import Fore, Style, init as colorama_init
    colorama_init()
except ImportError:
    class _F:
        GREEN = YELLOW = CYAN = RED = WHITE = RESET = ""
        BRIGHT = ""
    Fore = Style = _F()
    def colorama_init(): pass

G = Fore.GREEN + Style.BRIGHT
Y = Fore.YELLOW + Style.BRIGHT
C = Fore.CYAN + Style.BRIGHT
R = Fore.RED + Style.BRIGHT
W = Fore.WHITE
M = Fore.WHITE + Style.DIM if hasattr(Style, "DIM") else Fore.WHITE
Z = Style.RESET_ALL

BANNER = f"""
{G}  ╔══════════════════════════════════════════╗
  ║{Y}     🔍  PAINEL OSINTBR MONITOR  {G}         ║
  ║{W}   coleta · comparação · histórico      {G}║
  ╚══════════════════════════════════════════╝{Z}
"""

def clear():
    print("\033[2J\033[H", end="")

def banner():
    print(BANNER)

def info(msg: str):
    print(f"{C}[*]{Z} {msg}")

def ok(msg: str):
    print(f"{G}[+]{Z} {msg}")

def warn(msg: str):
    print(f"{Y}[!]{Z} {msg}")

def err(msg: str):
    print(f"{R}[-]{Z} {msg}")

def title(msg: str):
    print(f"\n{Y}▸ {msg}{Z}\n")

def progress(steps: list[str], delay: float = 0.35):
    for s in steps:
        print(f"{G}  →{Z} {s}", flush=True)
        time.sleep(delay)

def typewriter(text: str, delay: float = 0.008):
    for ch in text:
        sys.stdout.write(ch)
        sys.stdout.flush()
        time.sleep(delay)
    print()

def menu(options: list[tuple[str, str]]):
    print(f"{G}┌─ MENU ─────────────────────────{Z}")
    for num, label in options:
        print(f"{G}│{Z} {Y}{num}{Z}  {label}")
    print(f"{G}└────────────────────────────────{Z}")

def ask(prompt: str = "opção") -> str:
    try:
        return input(f"{Y}{prompt}>{Z} ").strip()
    except (EOFError, KeyboardInterrupt):
        print()
        return "0"

def pause():
    try:
        input(f"\n{M}[Enter para continuar]{Z}")
    except (EOFError, KeyboardInterrupt):
        print()
