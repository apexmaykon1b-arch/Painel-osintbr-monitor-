# -*- coding: utf-8 -*-
"""Verificação leve de username em URLs públicas (existência HTTP)."""
from __future__ import annotations
import requests

UA = {"User-Agent": "Painel-OSINTBR-Monitor/1.0"}

SITES = [
    ("GitHub", "https://github.com/{u}"),
    ("GitLab", "https://gitlab.com/{u}"),
    ("Reddit", "https://www.reddit.com/user/{u}"),
    ("TikTok", "https://www.tiktok.com/@{u}"),
    ("Instagram", "https://www.instagram.com/{u}/"),
    ("X/Twitter", "https://x.com/{u}"),
    ("YouTube", "https://www.youtube.com/@{u}"),
    ("Telegram", "https://t.me/{u}"),
    ("Linktree", "https://linktr.ee/{u}"),
    ("About.me", "https://about.me/{u}"),
    ("HackerNews", "https://news.ycombinator.com/user?id={u}"),
    ("Pinterest", "https://www.pinterest.com/{u}/"),
]

def check(username: str, timeout: float = 8.0) -> list[dict]:
    u = username.lstrip("@").strip()
    out = []
    for name, tpl in SITES:
        url = tpl.format(u=u)
        status = None
        exists = None
        err = None
        try:
            r = requests.get(url, headers=UA, timeout=timeout, allow_redirects=True)
            status = r.status_code
            # heurística simples
            if status == 404:
                exists = False
            elif status == 200:
                exists = True
            else:
                exists = None  # incerto (login wall etc.)
        except Exception as e:
            err = str(e)[:80]
        out.append({"site": name, "url": url, "status": status, "exists": exists, "error": err})
    return out
