# -*- coding: utf-8 -*-
"""Compara duas snapshots e lista mudanças."""
from __future__ import annotations

FIELDS = [
    ("name", "Nome"),
    ("bio", "Bio"),
    ("avatar", "Foto"),
    ("followers", "Seguidores"),
    ("following", "Seguindo"),
    ("posts", "Posts/repos"),
    ("public_repos", "Repos"),
    ("company", "Empresa"),
    ("location", "Local"),
    ("blog", "Blog"),
    ("twitter", "Twitter"),
    ("updated_at", "Atualização perfil"),
]

def diff(prev: dict | None, cur: dict) -> list[str]:
    if not prev:
        return ["Primeira coleta registrada"]
    msgs = []
    for key, label in FIELDS:
        a, b = prev.get(key), cur.get(key)
        if a is None and b is None:
            continue
        if str(a or "") != str(b or ""):
            msgs.append(f'{label}: "{str(a or "∅")[:60]}" → "{str(b or "∅")[:60]}"')
    if not msgs and prev.get("fingerprint") != cur.get("fingerprint"):
        msgs.append("Conteúdo/assinatura alterada")
    return msgs
