# -*- coding: utf-8 -*-
"""Coleta estável via API pública do GitHub."""
from __future__ import annotations
import requests

UA = {"User-Agent": "Painel-OSINTBR-Monitor/1.0", "Accept": "application/vnd.github+json"}

def collect(user_or_url: str) -> dict:
    u = user_or_url.strip().lstrip("@")
    if "github.com/" in u:
        u = u.split("github.com/")[-1].split("/")[0].split("?")[0]
    r = requests.get(f"https://api.github.com/users/{u}", headers=UA, timeout=20)
    if r.status_code == 404:
        raise ValueError(f"Usuário GitHub não encontrado: {u}")
    r.raise_for_status()
    j = r.json()
    repos = []
    try:
        rr = requests.get(
            f"https://api.github.com/users/{u}/repos?per_page=5&sort=updated",
            headers=UA, timeout=20,
        )
        if rr.ok:
            repos = [f"{x.get('name')}: {x.get('description') or ''}" for x in rr.json()[:5]]
    except Exception:
        pass
    return {
        "source": "GitHub API",
        "platform": "GitHub",
        "login": j.get("login"),
        "name": j.get("name") or j.get("login"),
        "bio": j.get("bio") or "",
        "avatar": j.get("avatar_url") or "",
        "company": j.get("company") or "",
        "location": j.get("location") or "",
        "blog": j.get("blog") or "",
        "twitter": j.get("twitter_username") or "",
        "email": j.get("email") or "",
        "followers": j.get("followers"),
        "following": j.get("following"),
        "public_repos": j.get("public_repos"),
        "public_gists": j.get("public_gists"),
        "created_at": j.get("created_at"),
        "updated_at": j.get("updated_at"),
        "url": j.get("html_url"),
        "repos_recent": repos,
        "fingerprint": "|".join([
            str(j.get("login")),
            str(j.get("bio")),
            str(j.get("followers")),
            str(j.get("public_repos")),
            str(j.get("updated_at")),
            str(j.get("avatar_url")),
        ]),
    }
