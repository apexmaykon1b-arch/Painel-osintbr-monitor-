# -*- coding: utf-8 -*-
"""Coleta de páginas públicas (HTML)."""
from __future__ import annotations
import re
import hashlib
import requests
from bs4 import BeautifulSoup

UA = {
    "User-Agent": (
        "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 "
        "(KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36"
    )
}

def _meta(soup: BeautifulSoup, prop: str = None, name: str = None) -> str:
    if prop:
        t = soup.find("meta", property=prop) or soup.find("meta", attrs={"property": prop})
        if t and t.get("content"):
            return t["content"].strip()
    if name:
        t = soup.find("meta", attrs={"name": name})
        if t and t.get("content"):
            return t["content"].strip()
    return ""

def collect(url: str) -> dict:
    if not re.match(r"^https?://", url, re.I):
        url = "https://" + url
    r = requests.get(url, headers=UA, timeout=25, allow_redirects=True)
    r.raise_for_status()
    html = r.text[:1_500_000]
    soup = BeautifulSoup(html, "html.parser")
    title = (soup.title.string.strip() if soup.title and soup.title.string else "")
    desc = _meta(soup, prop="og:description") or _meta(soup, name="description")
    image = _meta(soup, prop="og:image")
    og_title = _meta(soup, prop="og:title") or title
    text = soup.get_text(" ", strip=True)[:2000]
    emails = sorted(set(re.findall(r"[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}", text)))[:10]
    # números soltos perto de followers (melhor esforço)
    followers = None
    following = None
    posts = None
    for pat, key in [
        (r"([\d.,]+)\s*[Ff]ollowers", "followers"),
        (r"([\d.,]+)\s*[Ss]eguidores", "followers"),
        (r"([\d.,]+)\s*[Ff]ollowing", "following"),
        (r"([\d.,]+)\s*[Ss]eguindo", "following"),
        (r"([\d.,]+)\s*[Pp]osts", "posts"),
        (r'"followers_count"\s*:\s*(\d+)', "followers"),
        (r'"following_count"\s*:\s*(\d+)', "following"),
        (r'"media_count"\s*:\s*(\d+)', "posts"),
    ]:
        m = re.search(pat, html)
        if m:
            raw = m.group(1).replace(".", "").replace(",", "")
            try:
                val = int(float(raw)) if raw.replace(".", "", 1).isdigit() or raw.isdigit() else None
            except Exception:
                val = None
            if key == "followers" and followers is None:
                followers = val
            if key == "following" and following is None:
                following = val
            if key == "posts" and posts is None:
                posts = val
    blocked = bool(re.search(r"captcha|log in to continue|login to continue|automated requests", html[:300000], re.I))
    fp = hashlib.sha256(
        f"{og_title}|{desc}|{image}|{followers}|{following}|{posts}|{text[:400]}".encode("utf-8", errors="ignore")
    ).hexdigest()[:16]
    return {
        "source": "HTTP/HTML",
        "platform": _meta(soup, prop="og:site_name") or "Web",
        "name": og_title or title,
        "bio": desc,
        "avatar": image,
        "followers": followers,
        "following": following,
        "posts": posts,
        "url": r.url,
        "http": r.status_code,
        "emails": emails,
        "text": text[:500],
        "blocked": blocked,
        "fingerprint": fp,
        "warning": "Página parece exigir login/bloqueio" if blocked else "",
    }
